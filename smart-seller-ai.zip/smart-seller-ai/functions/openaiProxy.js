// ============================================================================
// functions/openaiProxy.js
//
// Exemplo de proxy para deploy como Cloudflare Worker (grátis). Ele existe
// para UMA coisa: a chave da OpenAI fica guardada como secret do lado do
// servidor, e nunca no navegador do consultor. O app (js/aiEngine.js) chama
// esse Worker; o Worker adiciona a chave e repassa para a OpenAI.
//
// COMO USAR:
//   1) npm i -g wrangler        (CLI da Cloudflare)
//   2) wrangler login
//   3) wrangler secret put OPENAI_API_KEY     (cole sua chave quando pedir)
//   4) wrangler deploy openaiProxy.js
//   5) copie a URL gerada (ex.: https://seu-proxy.workers.dev) e cole em
//      Configurações → "Endpoint (proxy recomendado)" no app.
//
// Isso é só um EXEMPLO — qualquer função serverless (Vercel, Netlify, AWS
// Lambda) serve, desde que faça o mesmo: receber o corpo da requisição,
// anexar a chave, repassar para a OpenAI e devolver a resposta com CORS
// liberado para o domínio do GitHub Pages onde o app está publicado.
// ============================================================================

export default {
  async fetch(request, env) {
    // CORS — troque '*' pelo domínio real do seu GitHub Pages em produção.
    const corsHeaders = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    };

    if (request.method === 'OPTIONS') return new Response(null, { headers: corsHeaders });
    if (request.method !== 'POST') return new Response('Method not allowed', { status: 405, headers: corsHeaders });

    let body;
    try { body = await request.json(); }
    catch { return new Response('JSON inválido', { status: 400, headers: corsHeaders }); }

    const resp = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        // A chave mora SÓ aqui — nunca no código do front-end.
        Authorization: `Bearer ${env.OPENAI_API_KEY}`
      },
      body: JSON.stringify(body)
    });

    const data = await resp.text();
    return new Response(data, {
      status: resp.status,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
};
