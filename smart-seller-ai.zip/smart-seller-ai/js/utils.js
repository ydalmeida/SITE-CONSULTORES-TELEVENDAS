// ============================================================================
// utils.js — funções puras e compartilhadas por todos os outros módulos.
// Sem estado, sem efeitos colaterais (exceto os helpers de storage, que só
// encapsulam localStorage). Isso é o que faz o resto do app ficar pequeno.
// ============================================================================

export const REGIAO_UF = {
  AC: 'Norte', AP: 'Norte', AM: 'Norte', PA: 'Norte', RO: 'Norte', RR: 'Norte', TO: 'Norte',
  AL: 'Nordeste', BA: 'Nordeste', CE: 'Nordeste', MA: 'Nordeste', PB: 'Nordeste',
  PE: 'Nordeste', PI: 'Nordeste', RN: 'Nordeste', SE: 'Nordeste',
  DF: 'Centro-Oeste', GO: 'Centro-Oeste', MT: 'Centro-Oeste', MS: 'Centro-Oeste',
  ES: 'Sudeste', MG: 'Sudeste', RJ: 'Sudeste', SP: 'Sudeste',
  PR: 'Sul', RS: 'Sul', SC: 'Sul'
};

export function semAcento(s) {
  return (s || '').toString().normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
}

export function apenasNumeros(s) {
  return (s || '').toString().replace(/\D/g, '');
}

export function formatarCNPJ(cnpj) {
  const c = apenasNumeros(cnpj);
  return c.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, '$1.$2.$3/$4-$5');
}

export function validarCNPJ(cnpjRaw) {
  const cnpj = apenasNumeros(cnpjRaw);
  if (cnpj.length !== 14 || /^(\d)\1{13}$/.test(cnpj)) return false;
  const calcDV = (base) => {
    let peso = base.length - 7, soma = 0;
    for (let i = 0; i < base.length; i++) { soma += Number(base[i]) * peso; peso = (peso === 2) ? 9 : peso - 1; }
    const r = soma % 11;
    return r < 2 ? 0 : 11 - r;
  };
  const dv1 = calcDV(cnpj.substring(0, 12));
  if (dv1 !== Number(cnpj[12])) return false;
  const dv2 = calcDV(cnpj.substring(0, 13));
  return dv2 === Number(cnpj[13]);
}

export function formatarMoeda(v) {
  const n = Number(v || 0);
  return n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

export function formatarData(iso) {
  if (!iso) return '—';
  try {
    const d = new Date(iso.length === 10 ? iso + 'T00:00:00' : iso);
    if (isNaN(d.getTime())) return iso;
    return d.toLocaleDateString('pt-BR');
  } catch { return iso; }
}

export function escapeHtml(str) {
  const d = document.createElement('div');
  d.textContent = str == null ? '' : String(str);
  return d.innerHTML;
}

export function debounce(fn, wait = 250) {
  let t = null;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), wait); };
}

export function uid(prefix = 'ID') {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}

// ── Storage: uma camada fina sobre localStorage, com namespace e JSON. ──────
const NS = 'ssai_'; // Smart Seller AI

export const storage = {
  get(key, fallback = null) {
    try {
      const raw = localStorage.getItem(NS + key);
      return raw == null ? fallback : JSON.parse(raw);
    } catch { return fallback; }
  },
  set(key, value) {
    try { localStorage.setItem(NS + key, JSON.stringify(value)); return true; }
    catch (e) { console.error('storage.set falhou:', e); return false; }
  },
  remove(key) { localStorage.removeItem(NS + key); }
};

export function toast(msg, type = 'info') {
  const box = document.getElementById('toastContainer');
  if (!box) { console.log(`[${type}] ${msg}`); return; }
  const icon = { success: 'fa-circle-check', error: 'fa-circle-exclamation', info: 'fa-circle-info' }[type] || 'fa-circle-info';
  const el = document.createElement('div');
  el.className = `toast toast-${type}`;
  el.innerHTML = `<i class="fa-solid ${icon}"></i><span>${escapeHtml(msg)}</span>`;
  box.appendChild(el);
  setTimeout(() => { el.classList.add('toast-out'); setTimeout(() => el.remove(), 220); }, 4000);
}
