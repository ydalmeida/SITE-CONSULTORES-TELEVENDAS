// ============================================================================
// history.js — histórico de consultas: empresa consultada, produtos
// sugeridos, data e consultor responsável.
// ============================================================================

import { storage, uid } from './utils.js';

function ler() { return storage.get('historico', []); }
function gravar(lista) { storage.set('historico', lista); }

export function registrarConsulta({ empresa, produtosSugeridos, consultor }) {
  const lista = ler();
  const registro = {
    id: uid('H'),
    data: new Date().toISOString(),
    cnpj: empresa.cnpj,
    razaoSocial: empresa.razaoSocial,
    cidade: empresa.municipio,
    estado: empresa.uf,
    segmento: empresa.cnaeDescricao,
    consultor: consultor || '—',
    produtosSugeridos: produtosSugeridos.map(p => ({ id: p.id, nome: p.nome, score: p.score, probabilidade: p.probabilidade }))
  };
  lista.unshift(registro);
  gravar(lista.slice(0, 2000));
  return registro;
}

export function listar() { return ler(); }

export function estatisticasBasicas() {
  const lista = ler();
  const contarPor = (campo) => {
    const mapa = {};
    lista.forEach(r => { const k = r[campo] || '—'; mapa[k] = (mapa[k] || 0) + 1; });
    return Object.entries(mapa).sort((a, b) => b[1] - a[1]);
  };
  const produtos = {};
  lista.forEach(r => r.produtosSugeridos.forEach(p => { produtos[p.nome] = (produtos[p.nome] || 0) + 1; }));

  return {
    totalConsultas: lista.length,
    porCidade: contarPor('cidade').slice(0, 10),
    porEstado: contarPor('estado').slice(0, 10),
    porConsultor: contarPor('consultor').slice(0, 10),
    produtosMaisRecomendados: Object.entries(produtos).sort((a, b) => b[1] - a[1]).slice(0, 10)
  };
}
