// ============================================================================
// learningEngine.js — "Learning Engine"
//
// Hoje só ARMAZENA o desfecho de cada recomendação (produto recomendado,
// vendido ou recusado, cidade, estado, segmento, consultor, data, cliente,
// motivo). Não tem machine learning ainda — de propósito: o briefing pede
// que essa estrutura esteja pronta para, no futuro, alimentar um modelo que
// substitua gradualmente os pesos manuais do recommendationEngine.js.
//
// getEstatisticas() já expõe agregações prontas para o dashboard usar.
// ============================================================================

import { storage, uid } from './utils.js';

function ler() { return storage.get('feedback', []); }
function gravar(lista) { storage.set('feedback', lista); }

/**
 * @param {Object} registro
 * @param {string} registro.produtoId
 * @param {string} registro.produtoNome
 * @param {'vendido'|'recusado'} registro.desfecho
 * @param {string} registro.cnpj
 * @param {string} registro.cliente
 * @param {string} registro.cidade
 * @param {string} registro.estado
 * @param {string} registro.segmento
 * @param {string} registro.consultor
 * @param {string} [registro.motivo]
 */
export function registrarDesfecho(registro) {
  const lista = ler();
  lista.unshift({
    id: uid('FB'),
    data: new Date().toISOString(),
    ...registro
  });
  gravar(lista.slice(0, 5000)); // teto de segurança
}

export function listar() { return ler(); }

export function getEstatisticas() {
  const lista = ler();
  const vendidos = lista.filter(r => r.desfecho === 'vendido');
  const recusados = lista.filter(r => r.desfecho === 'recusado');

  const contarPor = (arr, campo) => {
    const mapa = {};
    arr.forEach(r => { const k = r[campo] || '—'; mapa[k] = (mapa[k] || 0) + 1; });
    return Object.entries(mapa).sort((a, b) => b[1] - a[1]);
  };

  return {
    totalFeedbacks: lista.length,
    totalVendidos: vendidos.length,
    totalRecusados: recusados.length,
    taxaConversao: lista.length ? Math.round((vendidos.length / lista.length) * 100) : 0,
    produtosMaisVendidos: contarPor(vendidos, 'produtoNome').slice(0, 8),
    produtosMaisRecusados: contarPor(recusados, 'produtoNome').slice(0, 8),
    motivosRecusa: contarPor(recusados, 'motivo').slice(0, 8)
  };
}
