// ============================================================================
// app.js — orquestra os demais módulos e cuida da UI. Não tem regra de
// negócio própria: tudo aqui é "chame o módulo certo e desenhe o resultado".
// ============================================================================

import { toast, escapeHtml, formatarCNPJ, formatarMoeda, formatarData, validarCNPJ } from './utils.js';
import * as Auth from './auth.js';
import * as Products from './products.js';
import * as Engine from './recommendationEngine.js';
import * as AIEngine from './aiEngine.js';
import * as History from './history.js';
import * as Learning from './learningEngine.js';
import * as Dashboard from './dashboard.js';

let empresaAtual = null;
let recomendacaoAtual = []; // cards finais (pós IA/fallback)
let feedbackContexto = null; // { produtoId, produtoNome, desfecho }

// ── BOOT ─────────────────────────────────────────────────────────────────
async function boot() {
  await Products.init();
  wireLogin();
  wireSidebar();
  wireConsulta();
  wireProdutos();
  wireConfiguracoes();
  wireFeedbackModal();

  const usuario = Auth.getUsuarioAtual();
  if (usuario) entrarNoApp(usuario);
}
document.addEventListener('DOMContentLoaded', boot);

// ── LOGIN LOCAL (ver auth.js para o motivo de não ser Firebase de verdade) ──
function wireLogin() {
  document.getElementById('formLogin').addEventListener('submit', (e) => {
    e.preventDefault();
    const nome = document.getElementById('loginNome').value.trim();
    const papel = document.getElementById('loginPapel').value;
    if (!nome) { toast('Informe seu nome.', 'error'); return; }
    entrarNoApp(Auth.login({ nome, papel }));
  });
  document.getElementById('btnLogout').addEventListener('click', () => {
    Auth.logout();
    location.reload();
  });
}

function entrarNoApp(usuario) {
  document.getElementById('loginGate').style.display = 'none';
  document.getElementById('appShell').style.display = 'grid';
  document.getElementById('userNome').textContent = usuario.nome;
  document.getElementById('userPapel').textContent = usuario.papel === 'admin' ? 'Administrador' : 'Consultor';
  document.querySelectorAll('.admin-only').forEach(el => el.style.display = Auth.isAdmin() ? '' : 'none');
  mostrarAba('recomendacao');
}

// ── NAVEGAÇÃO ────────────────────────────────────────────────────────────
function wireSidebar() {
  document.querySelectorAll('.nav-item').forEach(btn => {
    btn.addEventListener('click', () => mostrarAba(btn.dataset.tab));
  });
}
function mostrarAba(tab) {
  document.querySelectorAll('.nav-item').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.toggle('active', p.id === 'tab-' + tab));
  if (tab === 'produtos') renderProdutosTable();
  if (tab === 'dashboard') Dashboard.render();
  if (tab === 'historico') renderHistorico();
  if (tab === 'configuracoes') renderConfiguracoes();
}

// ── FLUXO PRINCIPAL: CONSULTA CNPJ → RECOMENDAÇÃO ───────────────────────────
function wireConsulta() {
  document.getElementById('formConsulta').addEventListener('submit', async (e) => {
    e.preventDefault();
    const cnpjInput = document.getElementById('cnpjInput');
    const cnpj = cnpjInput.value;
    if (!validarCNPJ(cnpj)) { toast('CNPJ inválido — confira os dígitos.', 'error'); return; }
    await executarFluxoCompleto(cnpj);
  });
}

async function executarFluxoCompleto(cnpj) {
  setStatusConsulta('🔎 Consultando dados públicos do CNPJ…', true);
  esconder('empresaCard'); esconder('recomendacoesWrap');
  try {
    // 1) Data Collector
    const { consultarCNPJ } = await import('./api.js');
    empresaAtual = await consultarCNPJ(cnpj);
    renderEmpresaCard(empresaAtual);

    // 2) Smart Recommendation Engine — score em TODO o catálogo, top 20
    setStatusConsulta('⚙️ Calculando aderência com o catálogo (motor de regras)…', true);
    const produtos = Products.listar({ apenasAtivos: true });
    if (!produtos.length) { setStatusConsulta('Nenhum produto ativo cadastrado — vá em "Produtos" e cadastre o catálogo.', false); return; }
    const top20 = Engine.recomendar(empresaAtual, produtos, { topN: 20 });

    // 3) AI Sales Specialist — interpreta e escolhe os 5 melhores DENTRE o top 20
    setStatusConsulta('🤖 Consultor de IA analisando os 20 produtos pré-selecionados…', true);
    recomendacaoAtual = await AIEngine.gerarRecomendacaoFinal(empresaAtual, top20);

    renderRecomendacoes(recomendacaoAtual);
    setStatusConsulta('', false);

    // 4) grava no histórico
    const usuario = Auth.getUsuarioAtual();
    History.registrarConsulta({ empresa: empresaAtual, produtosSugeridos: recomendacaoAtual, consultor: usuario?.nome });
  } catch (e) {
    setStatusConsulta(`⚠️ ${e.message}`, false);
    toast(e.message, 'error');
  }
}

function setStatusConsulta(msg, loading) {
  const el = document.getElementById('statusConsulta');
  el.innerHTML = loading ? `<span class="spinner"></span> ${escapeHtml(msg)}` : escapeHtml(msg);
}

function renderEmpresaCard(empresa) {
  const el = document.getElementById('empresaCard');
  el.innerHTML = `
    <div class="empresa-head">
      <div>
        <div class="empresa-razao">${escapeHtml(empresa.razaoSocial)}</div>
        ${empresa.nomeFantasia ? `<div class="empresa-fantasia">${escapeHtml(empresa.nomeFantasia)}</div>` : ''}
      </div>
      <span class="badge ${empresa.situacao.includes('ATIVA') ? 'badge-ok' : 'badge-warn'}">${escapeHtml(empresa.situacao)}</span>
    </div>
    <div class="empresa-grid">
      <div><label>Cidade/UF</label><p>${escapeHtml(empresa.municipio)}/${escapeHtml(empresa.uf)} <span class="muted">(${escapeHtml(empresa.regiao)})</span></p></div>
      <div><label>Porte</label><p>${escapeHtml(empresa.porte)}</p></div>
      <div><label>CNAE Principal</label><p>${escapeHtml(empresa.cnaePrincipal)} — ${escapeHtml(empresa.cnaeDescricao)}</p></div>
      <div><label>Natureza Jurídica</label><p>${escapeHtml(empresa.naturezaJuridica)}</p></div>
      <div><label>Capital Social</label><p>${formatarMoeda(empresa.capitalSocial)}</p></div>
      <div><label>Abertura</label><p>${formatarData(empresa.dataAbertura)}</p></div>
    </div>
    ${empresa.cnaesSecundarios.length ? `<div class="empresa-cnaes-sec"><label>CNAEs Secundários</label><p>${empresa.cnaesSecundarios.map(c => escapeHtml(c.codigo + ' — ' + c.descricao)).join(' · ')}</p></div>` : ''}
  `;
  mostrar('empresaCard');
}

function renderRecomendacoes(cards) {
  const wrap = document.getElementById('recomendacoesGrid');
  if (!cards.length) { wrap.innerHTML = '<p class="muted">Nenhum produto com aderência suficiente foi encontrado.</p>'; mostrar('recomendacoesWrap'); return; }
  wrap.innerHTML = cards.map((c, i) => cardHTML(c, i)).join('');
  mostrar('recomendacoesWrap');
}

function cardHTML(c, posicao) {
  const barrasCriterios = Object.entries(c.criterios).map(([k, v]) => `
    <div class="crit-row" title="${escapeHtml(c.labelsCriterios[k])}: ${v}/100">
      <span class="crit-label">${escapeHtml(c.labelsCriterios[k])}</span>
      <div class="crit-bar-bg"><div class="crit-bar-fill" style="width:${v}%"></div></div>
      <span class="crit-val">${v}</span>
    </div>`).join('');

  const complementares = (c.complementares || []).map(id => {
    const p = Products.obter(id);
    return p ? `<span class="chip">${escapeHtml(p.nome)}</span>` : '';
  }).join('');

  return `
  <div class="reco-card">
    <div class="reco-top">
      <span class="reco-pos">#${posicao + 1}</span>
      <span class="reco-emoji">${c.imagem || '📦'}</span>
      <div class="reco-score" title="Score do motor de regras (rastreabilidade abaixo)">
        <svg viewBox="0 0 36 36" class="score-ring">
          <path class="score-bg" d="M18 2a16 16 0 1 1 0 32 16 16 0 1 1 0-32" />
          <path class="score-fg" stroke-dasharray="${c.score}, 100" d="M18 2a16 16 0 1 1 0 32 16 16 0 1 1 0-32" />
        </svg>
        <span class="score-num">${Math.round(c.score)}</span>
      </div>
    </div>
    <h3 class="reco-nome">${escapeHtml(c.nome)}</h3>
    <p class="reco-meta">${escapeHtml(c.marca || '')} · ${escapeHtml(c.categoria || '')} · ${formatarMoeda(c.preco)}</p>
    <p class="reco-prob"><i class="fa-solid fa-bolt"></i> Probabilidade de venda: <strong>${c.probabilidade}%</strong></p>

    <details class="reco-detalhes" open>
      <summary>Por que este produto?</summary>
      <p class="reco-texto"><strong>Motivo:</strong> ${escapeHtml(c.motivo)}</p>
      <p class="reco-texto"><strong>Problema que resolve:</strong> ${escapeHtml(c.problemaResolve)}</p>
      <p class="reco-texto"><strong>Benefício:</strong> ${escapeHtml(c.beneficio)}</p>
      <p class="reco-texto"><strong>Argumento de venda:</strong> ${escapeHtml(c.argumento)}</p>
      <p class="reco-texto"><strong>Abordagem sugerida:</strong> ${escapeHtml(c.abordagem)}</p>
      ${c.objecoes?.length ? `<p class="reco-texto"><strong>Objeções comuns:</strong> ${c.objecoes.map(escapeHtml).join(' · ')}</p>` : ''}
      ${complementares ? `<div class="reco-texto"><strong>Complementares:</strong><div class="chips">${complementares}</div></div>` : ''}
    </details>

    <details class="reco-rastreio">
      <summary>Rastreabilidade do score</summary>
      ${barrasCriterios}
    </details>

    <div class="reco-actions">
      <button class="btn btn-ghost" data-add="${c.id}"><i class="fa-regular fa-star"></i> Favoritar</button>
      <button class="btn btn-success" data-vendido="${c.id}" data-nome="${escapeHtml(c.nome)}"><i class="fa-solid fa-check"></i> Vendido</button>
      <button class="btn btn-danger-outline" data-recusado="${c.id}" data-nome="${escapeHtml(c.nome)}"><i class="fa-solid fa-xmark"></i> Recusado</button>
    </div>
  </div>`;
}

document.addEventListener('click', (e) => {
  const add = e.target.closest('[data-add]');
  if (add) { toast('Produto favoritado.', 'success'); return; }
  const vendido = e.target.closest('[data-vendido]');
  if (vendido) { abrirFeedbackModal(vendido.dataset.vendido, vendido.dataset.nome, 'vendido'); return; }
  const recusado = e.target.closest('[data-recusado]');
  if (recusado) { abrirFeedbackModal(recusado.dataset.recusado, recusado.dataset.nome, 'recusado'); return; }
});

// ── FEEDBACK (Learning Engine) ──────────────────────────────────────────────
function wireFeedbackModal() {
  document.getElementById('formFeedback').addEventListener('submit', (e) => {
    e.preventDefault();
    if (!feedbackContexto || !empresaAtual) return;
    Learning.registrarDesfecho({
      produtoId: feedbackContexto.produtoId,
      produtoNome: feedbackContexto.produtoNome,
      desfecho: feedbackContexto.desfecho,
      cnpj: empresaAtual.cnpj,
      cliente: document.getElementById('feedbackCliente').value.trim() || empresaAtual.razaoSocial,
      cidade: empresaAtual.municipio,
      estado: empresaAtual.uf,
      segmento: empresaAtual.cnaeDescricao,
      consultor: Auth.getUsuarioAtual()?.nome,
      motivo: document.getElementById('feedbackMotivo').value.trim()
    });
    toast('Registro salvo — obrigado, isso alimenta o aprendizado futuro do motor.', 'success');
    fecharModal('feedbackModal');
  });
  document.querySelectorAll('[data-close-modal]').forEach(b => b.addEventListener('click', () => fecharModal(b.dataset.closeModal)));
}
function abrirFeedbackModal(produtoId, produtoNome, desfecho) {
  feedbackContexto = { produtoId, produtoNome, desfecho };
  document.getElementById('feedbackTitulo').textContent = desfecho === 'vendido' ? `Marcar "${produtoNome}" como vendido` : `Marcar "${produtoNome}" como recusado`;
  document.getElementById('feedbackMotivoLabel').textContent = desfecho === 'vendido' ? 'Observação (opcional)' : 'Motivo da recusa';
  document.getElementById('feedbackCliente').value = '';
  document.getElementById('feedbackMotivo').value = '';
  abrirModal('feedbackModal');
}

// ── PRODUTOS (CRUD) ─────────────────────────────────────────────────────────
function wireProdutos() {
  document.getElementById('btnNovoProduto').addEventListener('click', () => abrirModalProduto());
  document.getElementById('formProduto').addEventListener('submit', (e) => {
    e.preventDefault();
    salvarFormularioProduto();
  });
  ['filtroBusca', 'filtroCategoria', 'filtroMarca', 'filtroSegmento', 'filtroEstado', 'filtroStatus']
    .forEach(id => document.getElementById(id).addEventListener('input', renderProdutosTable));

  document.getElementById('btnExportarJSON').addEventListener('click', () => {
    const blob = new Blob([Products.exportarJSON()], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'produtos.json';
    a.click();
  });
  document.getElementById('inputImportar').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    try {
      let n = 0;
      if (/\.json$/i.test(file.name)) n = Products.importarJSON(await file.text());
      else if (/\.csv$/i.test(file.name)) n = Products.importarCSV(await file.text());
      else if (/\.xlsx?$/i.test(file.name)) n = await Products.importarExcel(await file.arrayBuffer());
      else throw new Error('Formato não suportado — use .json, .csv ou .xlsx');
      toast(`${n} produto(s) importado(s)/atualizado(s).`, 'success');
      renderProdutosTable();
    } catch (err) { toast('Erro na importação: ' + err.message, 'error'); }
    e.target.value = '';
  });
}

function renderProdutosTable() {
  const filtros = {
    busca: valor('filtroBusca'), categoria: valor('filtroCategoria'), marca: valor('filtroMarca'),
    segmento: valor('filtroSegmento'), estado: valor('filtroEstado'), status: valor('filtroStatus')
  };
  const lista = Products.filtrar(filtros);
  preencherSelect('filtroCategoria', Products.opcoesUnicas('categoria'), filtros.categoria);
  preencherSelect('filtroMarca', Products.opcoesUnicas('marca'), filtros.marca);

  const tbody = document.getElementById('produtosTbody');
  document.getElementById('produtosContagem').textContent = `${lista.length} produto(s)`;
  if (!lista.length) { tbody.innerHTML = `<tr><td colspan="8" class="empty-cell">Nenhum produto encontrado.</td></tr>`; return; }
  tbody.innerHTML = lista.map(p => `
    <tr>
      <td>${p.imagem || '📦'}</td>
      <td>
        <strong>${escapeHtml(p.nome)}</strong>
        <div class="muted small">${escapeHtml(p.marca || '')}</div>
      </td>
      <td>${escapeHtml(p.categoria)}</td>
      <td>${formatarMoeda(p.preco)}</td>
      <td>${p.margem}%</td>
      <td>${p.prioridade}/5</td>
      <td><span class="badge ${p.status === 'ativo' ? 'badge-ok' : 'badge-off'}">${p.status}</span></td>
      <td class="td-actions">
        <button class="btn-icon" data-edit="${p.id}" title="Editar"><i class="fa-solid fa-pen"></i></button>
        <button class="btn-icon danger" data-del="${p.id}" title="Excluir"><i class="fa-solid fa-trash"></i></button>
      </td>
    </tr>`).join('');

  tbody.querySelectorAll('[data-edit]').forEach(b => b.addEventListener('click', () => abrirModalProduto(b.dataset.edit)));
  tbody.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', () => {
    if (confirm('Excluir este produto do catálogo?')) { Products.remover(b.dataset.del); renderProdutosTable(); toast('Produto excluído.', 'info'); }
  }));
}

function abrirModalProduto(id) {
  const p = id ? Products.obter(id) : null;
  document.getElementById('produtoModalTitulo').textContent = p ? 'Editar produto' : 'Novo produto';
  const f = document.getElementById('formProduto');
  f.reset();
  f.elements.id.value = p?.id || '';
  f.elements.nome.value = p?.nome || '';
  f.elements.marca.value = p?.marca || '';
  f.elements.categoria.value = p?.categoria || '';
  f.elements.subcategoria.value = p?.subcategoria || '';
  f.elements.preco.value = p?.preco ?? '';
  f.elements.margem.value = p?.margem ?? '';
  f.elements.imagem.value = p?.imagem || '📦';
  f.elements.descricao.value = p?.descricao || '';
  f.elements.palavrasChave.value = (p?.palavrasChave || []).join(', ');
  f.elements.segmentos.value = (p?.segmentos || []).join(', ');
  f.elements.cnaesCompativeis.value = (p?.cnaesCompativeis || []).join(', ');
  f.elements.estadosPreferenciais.value = (p?.estadosPreferenciais || []).join(', ');
  f.elements.regioes.value = (p?.regioes || []).join(', ');
  f.elements.pesoComercial.value = p?.pesoComercial ?? 3;
  f.elements.prioridade.value = p?.prioridade ?? 3;
  f.elements.relacionados.value = (p?.relacionados || []).join(', ');
  f.elements.status.value = p?.status || 'ativo';
  abrirModal('produtoModal');
}

function salvarFormularioProduto() {
  const f = document.getElementById('formProduto');
  const listaDe = (nome) => f.elements[nome].value.split(',').map(s => s.trim()).filter(Boolean);
  const produto = {
    id: f.elements.id.value || undefined,
    nome: f.elements.nome.value.trim(),
    marca: f.elements.marca.value.trim(),
    categoria: f.elements.categoria.value.trim() || 'Geral',
    subcategoria: f.elements.subcategoria.value.trim(),
    preco: Number(f.elements.preco.value) || 0,
    margem: Number(f.elements.margem.value) || 0,
    imagem: f.elements.imagem.value.trim() || '📦',
    descricao: f.elements.descricao.value.trim(),
    palavrasChave: listaDe('palavrasChave'),
    segmentos: listaDe('segmentos'),
    cnaesCompativeis: listaDe('cnaesCompativeis'),
    estadosPreferenciais: listaDe('estadosPreferenciais'),
    regioes: listaDe('regioes'),
    pesoComercial: Number(f.elements.pesoComercial.value) || 3,
    prioridade: Number(f.elements.prioridade.value) || 3,
    relacionados: listaDe('relacionados'),
    status: f.elements.status.value
  };
  if (!produto.nome) { toast('Informe o nome do produto.', 'error'); return; }
  Products.salvar(produto);
  toast('Produto salvo.', 'success');
  fecharModal('produtoModal');
  renderProdutosTable();
}

// ── HISTÓRICO ────────────────────────────────────────────────────────────
function renderHistorico() {
  const lista = History.listar();
  const tbody = document.getElementById('historicoTbody');
  if (!lista.length) { tbody.innerHTML = `<tr><td colspan="6" class="empty-cell">Nenhuma consulta realizada ainda.</td></tr>`; return; }
  tbody.innerHTML = lista.slice(0, 200).map(r => `
    <tr>
      <td>${formatarData(r.data)}</td>
      <td>${formatarCNPJ(r.cnpj)}</td>
      <td>${escapeHtml(r.razaoSocial)}</td>
      <td>${escapeHtml(r.cidade)}/${escapeHtml(r.estado)}</td>
      <td>${escapeHtml(r.consultor)}</td>
      <td>${r.produtosSugeridos.map(p => escapeHtml(p.nome)).join(', ')}</td>
    </tr>`).join('');
}

// ── CONFIGURAÇÕES (pesos + IA) ──────────────────────────────────────────────
const CAMPOS_PESO = ['cnae', 'segmento', 'regional', 'prioridade', 'margem', 'relacionados'];

function wireConfiguracoes() {
  CAMPOS_PESO.forEach(k => {
    document.getElementById('peso_' + k).addEventListener('input', atualizarSomaPesos);
  });
  document.getElementById('btnSalvarPesos').addEventListener('click', () => {
    const pesos = {};
    CAMPOS_PESO.forEach(k => pesos[k] = Number(document.getElementById('peso_' + k).value) / 100);
    Engine.salvarPesos(pesos);
    toast('Pesos do motor de recomendação atualizados.', 'success');
  });
  document.getElementById('btnResetarPesos').addEventListener('click', () => {
    Engine.resetarPesos();
    renderConfiguracoes();
    toast('Pesos restaurados para o padrão.', 'info');
  });

  document.getElementById('formIA').addEventListener('submit', (e) => {
    e.preventDefault();
    AIEngine.salvarConfigIA({
      ativo: document.getElementById('iaAtivo').checked,
      endpoint: document.getElementById('iaEndpoint').value.trim(),
      apiKey: document.getElementById('iaApiKey').value.trim(),
      modelo: document.getElementById('iaModelo').value.trim() || 'gpt-4o-mini'
    });
    toast('Configuração de IA salva neste navegador.', 'success');
  });
}

function renderConfiguracoes() {
  const pesos = Engine.getPesos();
  CAMPOS_PESO.forEach(k => document.getElementById('peso_' + k).value = Math.round(pesos[k] * 100));
  atualizarSomaPesos();

  const cfg = AIEngine.getConfigIA();
  document.getElementById('iaAtivo').checked = !!cfg.ativo;
  document.getElementById('iaEndpoint').value = cfg.endpoint || '';
  document.getElementById('iaApiKey').value = cfg.apiKey || '';
  document.getElementById('iaModelo').value = cfg.modelo || 'gpt-4o-mini';
}

function atualizarSomaPesos() {
  const soma = CAMPOS_PESO.reduce((acc, k) => acc + Number(document.getElementById('peso_' + k).value || 0), 0);
  CAMPOS_PESO.forEach(k => document.getElementById('pesoVal_' + k).textContent = document.getElementById('peso_' + k).value + '%');
  const el = document.getElementById('somaPesos');
  el.textContent = soma + '%';
  el.style.color = soma === 100 ? 'var(--accent)' : 'var(--warn)';
}

// ── helpers de UI ────────────────────────────────────────────────────────
function mostrar(id) { document.getElementById(id).style.display = ''; }
function esconder(id) { document.getElementById(id).style.display = 'none'; }
function valor(id) { return document.getElementById(id).value; }
function abrirModal(id) { document.getElementById(id).classList.add('open'); }
function fecharModal(id) { document.getElementById(id).classList.remove('open'); }
function preencherSelect(id, opcoes, atual) {
  const el = document.getElementById(id);
  const atuais = new Set(Array.from(el.options).map(o => o.value));
  if (atuais.size - 1 === opcoes.length) return; // já preenchido, evita rebuild a cada tecla
  el.innerHTML = `<option value="">Todas</option>` + opcoes.map(o => `<option value="${escapeHtml(o)}">${escapeHtml(o)}</option>`).join('');
  el.value = atual || '';
}
document.querySelectorAll('.modal-overlay').forEach(m => m.addEventListener('click', (e) => { if (e.target === m) m.classList.remove('open'); }));
