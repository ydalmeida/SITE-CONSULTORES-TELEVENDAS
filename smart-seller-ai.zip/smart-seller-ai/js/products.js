// ============================================================================
// products.js — CRUD do catálogo de produtos.
// Guarda tudo em localStorage (chave "produtos"), semeado na primeira
// execução a partir de /data/products.json. Trocar isso por uma API real
// (REST, Firestore etc.) é só reescrever load()/persist() — o resto do app
// consome apenas as funções exportadas aqui, nunca o storage direto.
// ============================================================================

import { storage, uid } from './utils.js';

let cache = null;

async function seedInicial() {
  try {
    const resp = await fetch('./data/products.json');
    if (!resp.ok) return [];
    return await resp.json();
  } catch { return []; }
}

export async function init() {
  const salvos = storage.get('produtos', null);
  if (salvos && Array.isArray(salvos) && salvos.length) {
    cache = salvos;
  } else {
    cache = await seedInicial();
    persist();
  }
  return cache;
}

function persist() { storage.set('produtos', cache); }

export function listar({ apenasAtivos = false } = {}) {
  const lista = cache || [];
  return apenasAtivos ? lista.filter(p => p.status === 'ativo') : lista.slice();
}

export function obter(id) { return (cache || []).find(p => p.id === id) || null; }

export function salvar(produto) {
  if (!produto.id) produto.id = uid('P');
  const idx = cache.findIndex(p => p.id === produto.id);
  if (idx >= 0) cache[idx] = produto; else cache.push(produto);
  persist();
  return produto;
}

export function remover(id) {
  cache = cache.filter(p => p.id !== id);
  persist();
}

export function filtrar({ busca = '', categoria = '', marca = '', segmento = '', estado = '', status = '' } = {}) {
  const termo = busca.trim().toLowerCase();
  return listar().filter(p => {
    if (categoria && p.categoria !== categoria) return false;
    if (marca && p.marca !== marca) return false;
    if (status && p.status !== status) return false;
    if (estado && !(p.estadosPreferenciais || []).includes(estado)) return false;
    if (segmento && !(p.segmentos || []).some(s => s.toLowerCase().includes(segmento.toLowerCase()))) return false;
    if (termo) {
      const alvo = [p.nome, p.marca, p.categoria, p.subcategoria, ...(p.palavrasChave || [])]
        .join(' ').toLowerCase();
      if (!alvo.includes(termo)) return false;
    }
    return true;
  });
}

export function opcoesUnicas(campo) {
  return [...new Set(listar().map(p => p[campo]).filter(Boolean))].sort();
}

// ── Importação em massa ──────────────────────────────────────────────────
export function importarJSON(jsonTexto) {
  const arr = JSON.parse(jsonTexto);
  if (!Array.isArray(arr)) throw new Error('O arquivo precisa ser uma lista (array) de produtos.');
  arr.forEach(p => salvar(normalizarImportado(p)));
  return arr.length;
}

export function importarCSV(csvTexto) {
  const linhas = csvTexto.split(/\r?\n/).filter(l => l.trim());
  if (linhas.length < 2) throw new Error('CSV vazio ou sem dados.');
  const cabecalho = linhas[0].split(',').map(h => h.trim());
  let count = 0;
  for (let i = 1; i < linhas.length; i++) {
    const valores = linhas[i].split(',');
    const obj = {};
    cabecalho.forEach((h, idx) => obj[h] = (valores[idx] || '').trim());
    salvar(normalizarImportado(obj));
    count++;
  }
  return count;
}

// Se a biblioteca SheetJS (XLSX) estiver carregada na página, permite Excel também.
export async function importarExcel(arrayBuffer) {
  if (typeof XLSX === 'undefined') throw new Error('Biblioteca de Excel não carregada.');
  const wb = XLSX.read(arrayBuffer, { type: 'array' });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const linhas = XLSX.utils.sheet_to_json(ws, { defval: '' });
  linhas.forEach(l => salvar(normalizarImportado(l)));
  return linhas.length;
}

function normalizarImportado(o) {
  const listaDe = (v) => Array.isArray(v) ? v : (v ? String(v).split(/[;|]/).map(s => s.trim()).filter(Boolean) : []);
  return {
    id: o.id || undefined,
    nome: o.nome || 'Produto sem nome',
    marca: o.marca || '',
    categoria: o.categoria || 'Geral',
    subcategoria: o.subcategoria || '',
    preco: Number(o.preco) || 0,
    margem: Number(o.margem) || 0,
    imagem: o.imagem || '📦',
    descricao: o.descricao || '',
    palavrasChave: listaDe(o.palavrasChave || o.palavras_chave),
    segmentos: listaDe(o.segmentos),
    cnaesCompativeis: listaDe(o.cnaesCompativeis || o.cnaes_compativeis),
    estadosPreferenciais: listaDe(o.estadosPreferenciais || o.estados_preferenciais),
    regioes: listaDe(o.regioes),
    pesoComercial: Number(o.pesoComercial || o.peso_comercial) || 3,
    prioridade: Number(o.prioridade) || 3,
    relacionados: listaDe(o.relacionados),
    status: o.status === 'inativo' ? 'inativo' : 'ativo'
  };
}

export function exportarJSON() {
  return JSON.stringify(listar(), null, 2);
}
