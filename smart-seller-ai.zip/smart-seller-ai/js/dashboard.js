// ============================================================================
// dashboard.js — monta os gráficos (Chart.js) e os rankings do painel.
// Lê só de history.js e learningEngine.js — não sabe nada de UI de outras
// telas, e não escreve em nenhum storage.
// ============================================================================

import * as History from './history.js';
import * as Learning from './learningEngine.js';

let charts = {};

function destruirCharts() {
  Object.values(charts).forEach(c => c && c.destroy());
  charts = {};
}

const CORES = ['#6C5CE7', '#22D3B8', '#FF6B4A', '#F6C453', '#4C8DFF', '#E86BB0', '#8BD450', '#B98CFF'];

export function render() {
  destruirCharts();
  const histStats = History.estatisticasBasicas();
  const learnStats = Learning.getEstatisticas();

  // KPIs
  setText('kpiConsultas', histStats.totalConsultas);
  setText('kpiVendidos', learnStats.totalVendidos);
  setText('kpiRecusados', learnStats.totalRecusados);
  setText('kpiConversao', learnStats.taxaConversao + '%');

  // Produtos mais recomendados (motor de regras)
  charts.recomendados = new Chart(document.getElementById('chartRecomendados'), {
    type: 'bar',
    data: {
      labels: histStats.produtosMaisRecomendados.map(x => x[0]),
      datasets: [{ data: histStats.produtosMaisRecomendados.map(x => x[1]), backgroundColor: CORES[0], borderRadius: 6, maxBarThickness: 22 }]
    },
    options: baseOptionsBar('Vezes recomendado')
  });

  // Produtos mais vendidos vs recusados (learning engine)
  const nomesFeedback = [...new Set([
    ...learnStats.produtosMaisVendidos.map(x => x[0]),
    ...learnStats.produtosMaisRecusados.map(x => x[0])
  ])].slice(0, 8);
  const mapaVendidos = Object.fromEntries(learnStats.produtosMaisVendidos);
  const mapaRecusados = Object.fromEntries(learnStats.produtosMaisRecusados);
  charts.vendaVsRecusa = new Chart(document.getElementById('chartVendaRecusa'), {
    type: 'bar',
    data: {
      labels: nomesFeedback,
      datasets: [
        { label: 'Vendidos', data: nomesFeedback.map(n => mapaVendidos[n] || 0), backgroundColor: '#22D3B8', borderRadius: 6 },
        { label: 'Recusados', data: nomesFeedback.map(n => mapaRecusados[n] || 0), backgroundColor: '#FF6B4A', borderRadius: 6 }
      ]
    },
    options: { ...baseOptionsBar(''), plugins: { legend: { display: true, labels: { color: '#A9B4C0' } } } }
  });

  // Consultas por estado
  charts.estados = new Chart(document.getElementById('chartEstados'), {
    type: 'doughnut',
    data: {
      labels: histStats.porEstado.map(x => x[0]),
      datasets: [{ data: histStats.porEstado.map(x => x[1]), backgroundColor: CORES, borderColor: '#12161C', borderWidth: 2 }]
    },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'right', labels: { color: '#A9B4C0', boxWidth: 12, font: { size: 11 } } } } }
  });

  // Taxa de conversão (doughnut)
  charts.conversao = new Chart(document.getElementById('chartConversao'), {
    type: 'doughnut',
    data: {
      labels: ['Vendidos', 'Recusados', 'Sem retorno'],
      datasets: [{
        data: [learnStats.totalVendidos, learnStats.totalRecusados, Math.max(0, histStats.totalConsultas - learnStats.totalFeedbacks)],
        backgroundColor: ['#22D3B8', '#FF6B4A', '#2A3340'], borderColor: '#12161C', borderWidth: 2
      }]
    },
    options: { responsive: true, maintainAspectRatio: false, cutout: '68%', plugins: { legend: { position: 'bottom', labels: { color: '#A9B4C0', boxWidth: 12, font: { size: 11 } } } } }
  });

  renderRanking('rankingCidades', histStats.porCidade);
  renderRanking('rankingConsultores', histStats.porConsultor);
}

function renderRanking(elId, entradas) {
  const el = document.getElementById(elId);
  if (!el) return;
  if (!entradas.length) { el.innerHTML = '<p class="muted small">Sem dados ainda.</p>'; return; }
  const max = Math.max(...entradas.map(e => e[1]));
  el.innerHTML = entradas.map(([nome, qtd]) => `
    <div class="rank-row">
      <span class="rank-nome">${nome}</span>
      <div class="rank-bar-bg"><div class="rank-bar-fill" style="width:${Math.round((qtd / max) * 100)}%"></div></div>
      <span class="rank-qtd">${qtd}</span>
    </div>`).join('');
}

function baseOptionsBar(titulo) {
  return {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { display: false }, title: titulo ? { display: true, text: titulo, color: '#A9B4C0', font: { size: 11 } } : undefined },
    scales: {
      x: { ticks: { color: '#7C8AA0', font: { size: 10 } }, grid: { display: false } },
      y: { ticks: { color: '#7C8AA0', font: { size: 10 }, precision: 0 }, grid: { color: 'rgba(255,255,255,.05)' } }
    }
  };
}

function setText(id, val) { const el = document.getElementById(id); if (el) el.textContent = val; }
