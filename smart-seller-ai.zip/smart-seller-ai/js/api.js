// ============================================================================
// api.js — "Data Collector"
// Responsável por UMA coisa: dado um CNPJ, devolver os dados públicos da
// empresa já normalizados no formato interno que o resto do app consome.
//
// Fonte padrão: BrasilAPI (https://brasilapi.com.br/api/cnpj/v1/{cnpj}) —
// pública, gratuita, sem chave, e com CORS liberado (funciona 100% client-side
// no GitHub Pages, sem backend). Se sua empresa tiver uma API própria (Receita
// Federal paga, CNPJá, etc.), troque só a função `buscarBrasilAPI` — o resto
// do app não precisa saber de onde os dados vieram.
// ============================================================================

import { REGIAO_UF, apenasNumeros, validarCNPJ } from './utils.js';

const ENDPOINT = 'https://brasilapi.com.br/api/cnpj/v1/';

export class ErroConsultaCNPJ extends Error {}

/**
 * Consulta um CNPJ e devolve o objeto normalizado da empresa.
 * @param {string} cnpjRaw
 * @returns {Promise<Empresa>}
 */
export async function consultarCNPJ(cnpjRaw) {
  const cnpj = apenasNumeros(cnpjRaw);
  if (!validarCNPJ(cnpj)) throw new ErroConsultaCNPJ('CNPJ inválido — confira os dígitos.');

  let resp;
  try {
    resp = await fetch(ENDPOINT + cnpj);
  } catch (e) {
    throw new ErroConsultaCNPJ('Não consegui conectar à API de CNPJ. Verifique sua internet.');
  }
  if (resp.status === 404) throw new ErroConsultaCNPJ('CNPJ não encontrado na base da Receita Federal.');
  if (resp.status === 429) throw new ErroConsultaCNPJ('Muitas consultas em sequência — aguarde alguns segundos e tente de novo.');
  if (!resp.ok) throw new ErroConsultaCNPJ(`Erro na consulta (HTTP ${resp.status}).`);

  const d = await resp.json();
  return normalizar(cnpj, d);
}

function normalizar(cnpj, d) {
  const uf = d.uf || '';
  const cnaesSecundarios = (d.cnaes_secundarios || []).map(c => ({
    codigo: apenasNumeros(String(c.codigo || '')),
    descricao: c.descricao || ''
  }));

  return {
    cnpj,
    razaoSocial: d.razao_social || '—',
    nomeFantasia: d.nome_fantasia || '',
    municipio: d.municipio || '—',
    uf,
    regiao: REGIAO_UF[uf] || '—',
    cep: d.cep || '',
    cnaePrincipal: apenasNumeros(String(d.cnae_fiscal || '')),
    cnaeDescricao: d.cnae_fiscal_descricao || '—',
    cnaesSecundarios,
    naturezaJuridica: d.natureza_juridica || '—',
    porte: d.porte || d.descricao_porte || '—',
    situacao: (d.descricao_situacao_cadastral || 'INDEFINIDA').toUpperCase(),
    capitalSocial: Number(d.capital_social || 0),
    dataAbertura: d.data_inicio_atividade || '',
    endereco: [
      [d.descricao_tipo_de_logradouro, d.logradouro].filter(Boolean).join(' '),
      d.numero, d.bairro, d.municipio, uf
    ].filter(Boolean).join(', '),
    telefone: d.ddd_telefone_1 || '',
    email: d.email || ''
  };
}

/**
 * @typedef {Object} Empresa
 * @property {string} cnpj
 * @property {string} razaoSocial
 * @property {string} nomeFantasia
 * @property {string} municipio
 * @property {string} uf
 * @property {string} regiao
 * @property {string} cnaePrincipal
 * @property {string} cnaeDescricao
 * @property {{codigo:string,descricao:string}[]} cnaesSecundarios
 * @property {string} naturezaJuridica
 * @property {string} porte
 * @property {string} situacao
 * @property {number} capitalSocial
 * @property {string} dataAbertura
 */
