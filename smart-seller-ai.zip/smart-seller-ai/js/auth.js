// ============================================================================
// auth.js — controle de sessão do consultor.
//
// IMPORTANTE: o briefing original pede Firebase Authentication (Google + e-
// mail/senha) com permissões de Administrador/Consultor. Este módulo entrega
// a MESMA interface que o resto do app usa (getUsuarioAtual, login, logout,
// isAdmin) mas com uma implementação local (localStorage) — porque uma conta
// Firebase real precisa das credenciais do projeto do cliente, que não temos
// aqui. Para plugar o Firebase de verdade, troque só o corpo das funções
// abaixo por chamadas ao firebase/auth — nenhum outro módulo do app precisa
// mudar. Um exemplo comentado de como isso ficaria está no fim do arquivo.
// ============================================================================

import { storage } from './utils.js';

export function getUsuarioAtual() {
  return storage.get('usuario', null);
}

export function login({ nome, papel }) {
  const usuario = { nome: nome.trim(), papel: papel === 'admin' ? 'admin' : 'consultor', desde: new Date().toISOString() };
  storage.set('usuario', usuario);
  return usuario;
}

export function logout() {
  storage.remove('usuario');
}

export function isAdmin() {
  const u = getUsuarioAtual();
  return !!u && u.papel === 'admin';
}

/* ────────────────────────────────────────────────────────────────────────
   EXEMPLO — como plugar Firebase Authentication de verdade (não ativo):

   import { initializeApp } from 'firebase/app';
   import { getAuth, GoogleAuthProvider, signInWithPopup,
            signInWithEmailAndPassword, onAuthStateChanged, signOut } from 'firebase/auth';
   import { getFirestore, doc, getDoc } from 'firebase/firestore';

   const app = initializeApp({ ...suasCredenciais });
   const auth = getAuth(app);
   const db = getFirestore(app);

   export function loginGoogle() { return signInWithPopup(auth, new GoogleAuthProvider()); }
   export function loginEmail(email, senha) { return signInWithEmailAndPassword(auth, email, senha); }
   export function logout() { return signOut(auth); }
   export function onMudancaAuth(cb) {
     return onAuthStateChanged(auth, async (user) => {
       if (!user) return cb(null);
       const perfil = await getDoc(doc(db, 'users', user.uid));
       cb({ nome: user.displayName, email: user.email, papel: perfil.data()?.papel || 'consultor' });
     });
   }
   ──────────────────────────────────────────────────────────────────────── */
